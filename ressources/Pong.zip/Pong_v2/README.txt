GIRARD Thomas

Jeu du pong grandement inspiré de celui sorti au début années 80

le but est de marquer des points jusqu'à atteindre un score décidé avant de commencer la partie,
la vitesse de la balle augmente à chaque fois qu'un joueur la touche avec sa raquette jusqu'à ce 
qu'un point soit marqué par l'un des deux joueurs puis la vitesse de la balle est reinitialisée.

Deux modes sont disponible, 
	
	le mode "Joueur contre IA" où le joueur prend le contrôle de la raquette située à gauche de l'écran
	et affronte une pseudo intelligence artificielle qui réagit en fonction de la position de la balle.

	le mode "Joueur1 contre Joueur2" où deux joueurs s'affrontent (les touches correspondantes à chaque joueur
	sont rappelées en haut du menu.


Il est aussi possible de changer la difficulté de l'IA pour le mode "Joueur contre IA" ce qui modifie sa vitesse de déplacement

Enfin, une option permet de sélectionner le nombre de points qu'il faudra atteindre pour remporter la prochaine partie
et une autre permet de recommencer la partie avec les mêmes options.

note : la gestion des collisions n'est pas optimale (notamment lorsque la balle atteint une vitesse importante) mais je ne suis 
       pas parvenu à faire la méthode montrée dans le TP11 :) 