document.addEventListener("DOMContentLoaded", () => {
  let currentIndex = 0;
  showSlide(currentIndex);

  function showSlide(index) {
    const slides = document.getElementsByClassName("carousel-slide");
    if (index >= slides.length) {
      currentIndex = 0;
    } else if (index < 0) {
      currentIndex = slides.length - 1;
    } else {
      currentIndex = index;
    }

    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }

    slides[currentIndex].style.display = "flex";
  }

  document.getElementById("prev").addEventListener("click", () => {
    showSlide(currentIndex - 1);
  });
  document.getElementById("next").addEventListener("click", () => {
    showSlide(currentIndex + 1);
  });
});
